---
title: "A message from the program chairs of TAURIN 2021"
date: 2021-01-01
publishDate: 2023-02-15T21:46:59.435594Z
authors: ["R. Holz", "A. Abhishta"]
publication_types: ["1"]
abstract: ""
featured: false
publication: "*TAURIN 2021 - Proceedings of the 2021 ACM SIGCOMM Workshop on Technologies, Applications, and Uses of a Responsible Internet*"
---

