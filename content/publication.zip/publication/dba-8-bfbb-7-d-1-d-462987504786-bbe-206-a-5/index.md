---
title: "Picking Your Brains: Where and How Neuroscience Tools Can Enhance Marketing Research"
date: 2020-12-01
publishDate: 2023-02-15T21:46:59.434394Z
authors: ["Letizia Alvino", "Luigi Pavone", "Abhishta Abhishta", "Henry Robben"]
publication_types: ["2"]
abstract: "The use of neuroscience tools to study consumer behavior and the decision making process in marketing has improved our understanding of cognitive, neuronal, and emotional mechanisms related to marketing-relevant behavior. However, knowledge about neuroscience tools that are used in consumer neuroscience research is scattered. In this article, we present the results of a literature review that aims to provide an overview of the available consumer neuroscience tools and classifies them according to their characteristics. We analyse a total of 219 full-texts in the area of consumer neuroscience. Our findings suggest that there are seven tools that are currently used in consumer neuroscience research. In particular, electroencephalography (EEG) and eye tracking (ET) are the most commonly used tools in the field. We also find that consumer neuroscience tools are used to study consumer preferences and behaviors in different marketing domains such as advertising, branding, online experience, pricing, product development and product experience. Finally, we identify two ready-to-use platforms, namely iMotions and GRAIL that can help in integrating the measurements of different consumer neuroscience tools simultaneously. Measuring brain activity and physiological responses on a common platform could help by (1) reducing time and costs for experiments and (2) linking cognitive and emotional aspects with neuronal processes. Overall, this article provides relevant input in setting directions for future research and for business applications in consumer neuroscience. We hope that this study will provide help to researchers and practitioners in identifying available, non-invasive and useful tools to study consumer behavior."
featured: false
publication: "*Frontiers in Neuroscience*"
tags: ["Neuromarketing", "Consumer neuroscience", "Review", "iMotion", "GRAIL", "Marketing", "Neurophysiological tools", "Physiological tools"]
doi: "10.3389/fnins.2020.577666"
---

