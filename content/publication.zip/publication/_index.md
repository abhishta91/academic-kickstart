---
title: Publications

# View.
#   1 = List
#   2 = Compact
#   3 = Card
#   4 = Citation
view: 4

# Optional header image (relative to `static/img/` folder).
#header:
  #caption: ""
  #image: ""
---
